<!doctype html>

<html>
<head>
    <title>all-post</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/cosmo/bootstrap.min.css"
          integrity="sha384-5QFXyVb+lrCzdN228VS3HmzpiE7ZVwLQtkt+0d9W43LQMzz4HBnnqvVxKg6O+04d"
          crossorigin="anonymous">

</head>
</html>
<body>

<ul>
    <li><a href="/">Contact M</a>
    <li><a href="/home">Home</a></li>
    <li><a href="/registration">Registration</a></li>
    <li><a href="/newpost">New Post</a></li>

</ul>

</body>

<div class="container">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $singlePost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<!--        <nav>
            <table cellspacing="5" cellpadding="5">
                <tr>


        <link rel="stylesheet" href="newpost">

                    </tr>
                        </table>
                            </nav>-->

    <div class="col-md-12">
        <h1><a href="/post/<?php echo e($singlePost->id); ?>"><?php echo e($singlePost->title); ?></a></h1>
        <p>
            <?php echo e($singlePost->body); ?>

        </p>
        <div>
            <span class="badge">Posted <?php echo e($singlePost->created_at); ?></span>
        </div>
        <hr>
    </div>

        </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>
<div class="input-group">

</div>

</html>

