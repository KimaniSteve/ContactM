<!doctype html>

<html lang="eng">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,
	initial-scale=1-0">

    <title>Heading</title>
</head>
<p>
<h1>Heading</h1>
<p>

<ul>
    <li><a href="/">Contact M</a>
    <li><a href="/registration">Registration</a></li>
    <li><a href="/newpost">New Post</a></li>
    <li><a href="/all-posts">All Post</a></li>

</ul>
<body>

<div class="input-group">
    <button type="edit" name="edit" class="btn btn-secondary">Edit</button>



    <button type="delete" name="delete" class="btn btn-success">Delete</button>

</div>

<table cellspacing="5" cellpadding="5">
<h1>
<tr>
    <td><a href="#">Heading</a></td>
    <td><a href="heading">Heading</a></td>
    <td><a href="heading">Heading</a></td>
    <td><a href="heading">Heading</a></td>
    <td><a href="heading">Heading</a></td>
    <td><a href="heading">Heading</a></td>
</tr>
</h1>
</table>
</body>
</html>
