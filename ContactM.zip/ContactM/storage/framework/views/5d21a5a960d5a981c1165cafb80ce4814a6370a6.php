<!doctype html>

<html>
<head>
    <title>Edit-Post</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/cosmo/bootstrap.min.css"
          integrity="sha384-5QFXyVb+lrCzdN228VS3HmzpiE7ZVwLQtkt+0d9W43LQMzz4HBnnqvVxKg6O+04d"
          crossorigin="anonymous">
</head>

<h1>Edit-Post</h1>


<ul>
    <li><a href="/home">Home</a>
    <li><a href="/registration">Registration</a></li>
    <li><a href="/">Contact M</a></li>
    <li><a href="/all-posts">All Post</a></li>

</ul>


</html>

<div class="container">
    <div class="col-md-6">
        <form method="post" action="/update-post">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="post_id" value="<?php echo e($post->id); ?>">
            <div class="form-group">

                <label for="pwd">Post Title:</label>

                <input name="title" type="text" class="form-control" id="pwd" value="<?php echo e($post->title); ?>">
            </div>
            <div class="form-group">
                <label for="pwd">Post Body:</label>
                <textarea name="body" class="form-control"><?php echo e($post->body); ?></textarea>
            </div>

            <button type="submit" class="btn btn-secondary">Save Changes</button>


        </form>
    </div>
</div>





            <?php echo csrf_field(); ?>











</div>
