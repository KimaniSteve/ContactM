<!doctype html>

<html>
<head>
    <title>returnpost</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/cosmo/bootstrap.min.css"
          integrity="sha384-5QFXyVb+lrCzdN228VS3HmzpiE7ZVwLQtkt+0d9W43LQMzz4HBnnqvVxKg6O+04d"
          crossorigin="anonymous">

</head>

<body>
<h1></h1>


<ul>
    <li><a href="/">Contact M</a>
    <li><a href="/home">Home</a></li>
    <li><a href="/registration">Registration</a></li>
    <li><a href="/newpost">New Post</a></li>

</ul>

</body>

<div class="container">
    <div class="col-md-12">
        <h1>Revolution has begun!</h1>
        <p>'I am bound to Tahiti for more men.'
            'Very good. Let me board you a moment—I come in peace.
            ' With that he leaped from the canoe, swam to the boat;
            and climbing the gunwale, stood face to face with the captain.
            'Cross your arms, sir; throw back your head. Now, repeat after me.
            As soon as Steelkilt leaves me, I swear to beach this boat on yonder island, and remain there six days.
            If I do not, may lightning strike me!'A pretty scholar,' laughed the Lakeman.
            'Adios, Senor!' and leaping into the sea, he swam back to his comrades.</p>
        <div>
            <span class="badge">Posted 2012-08-02 20:47:04</span>
        </div>
        <hr>
    </div>
</div>
