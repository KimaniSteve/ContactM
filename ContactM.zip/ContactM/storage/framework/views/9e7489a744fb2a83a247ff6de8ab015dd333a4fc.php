<!DOCTYPE html>
<html>
<head>
	<title>User Registration</title>
</head>
<body>
	<div class="header">
		<h1> Login</h1>
	</div>
	
	<form method="post" action="login.php">
	<!-- display validation errors here -->
	
	<?php include('errors.php'); ?>
		<div class="input-group">
			<lable>Username</lable>
			<input type="text" name="username">
	</div>
	
	<div class="input-group">
	<lable>Password</lable>
	<input type="password" name="password">
	</div>
	
	<div class="input-group">
		<button type="submit" name="login" class="btn">Login</button>
		
		
	</div>
	
	<P>
		Not yet a member? <a href="register.php">Sign up</a>
		Not yet a member? <a href="register.php">Sign up</a>
	</P>
	</form>
</body>
</html>