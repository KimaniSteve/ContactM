<!doctype html>

<html lang="eng">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width,
	initial-scale=1-0">

<title>Home</title>
</head>
<body>
<h1>Home Welcome</h1>
<p>

<ul>
<li><a href="/">Contact M</a>
<li><a href="/registration">Registration</a></li>
<li><a href="/newpost">New Post</a></li>

</ul>
<p>



</body>

</html>
