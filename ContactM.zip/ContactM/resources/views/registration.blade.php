<!doctype html>

<html>
<head>
    <title></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootswatch/4.5.2/cosmo/bootstrap.min.css"
          integrity="sha384-5QFXyVb+lrCzdN228VS3HmzpiE7ZVwLQtkt+0d9W43LQMzz4HBnnqvVxKg6O+04d" crossorigin="anonymous">

</head>

<body>
<h1>Registration</h1>

<p>


<ul>
    <li><a href="/">Contact M</a>
    <li><a href="/home">Home</a></li>
    <li><a href="/newpost">New Post</a></li>

</ul>
<p>

<div class="container">
    <div class="col-md-6">
        <form action="">
            <div class="form-group">
                <label for="email">Email address:</label>
                <input type="email" class="form-control" id="email">
            </div>
            <div class="form-group">
                <label for="pwd">Password:</label>
                <input type="password" class="form-control" id="pwd">
            </div>

            <div class="checkbox">
                <label><input type="checkbox"> Remember me</label>
            </div>
            <button type="submit" class="btn btn-success">Submit</button>
        </form>
    </div>
</div>




</body>

</html>
