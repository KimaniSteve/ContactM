<!doctype html>

<html>
<head>
<title>Contact M</title>
</head>
<body>
<h1>Contact M</h1>
<p>

<ul>
    <li><a href="/home">Home</a></li>
    <li><a href="/newpost">New Post</a></li>
    <li><a href="/registration">Registration</a></li>


</ul>
<p>



</body>

</html>
